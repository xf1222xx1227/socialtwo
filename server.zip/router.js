const express = require('express')

const router = express.Router()
// 导入数据库 sqlFn('sql',[].res=>{})
const sqlFn=require('./mysql')

// 路由接口
// router.get('/',(req,res)=>{
//     res.send('hello')
// })

// router.get('/projectList',(req,res)=>{
//     const page=req.query.page || 1;
//     const sqlLen="select * from customers where customerid";
//     sqlFn(sqlLen,null,data => {
//         let len=data.length;
//         const sql="select * from customers order by customerid desc limit 8 offset "+(page-1)*8;
//         // const sql="select * from customers";
//         sqlFn(sql,null,result => {
//             if(result.length > 0){
//                 res.send({
//                     status: 200,
//                     data: result,
//                     pageSize: 8,
//                     total: len
//                 })
//             }else{
//                 res.send({
//                     status:500,
//                     msg:"暂无数据"
//                 })
//             }
//         })
//     })
// })

// router.get("/search",(req,res)=> {
//     var search = req.query.search;
//     const sql = "select * from products where concat(productid,productname) like '%' "+search;
//     sqlFn(sql,null,(result)=>{
//         if(result.length > 0){
//             res.send({
//                 status: 200,
//                 result
//             })
//         }else{
//             res.send({
//                 status:500,
//                 msg:"暂无数据"
//             })
//         }
//     })
// })

// 社科下属账户
router.get("/bidding_user",(req,res)=> {
    var search = req.query.search;
    const sql = "select * from bidding_user "+search;
    sqlFn(sql,null,(result)=>{
        if(result.length > 0){
            res.send({
                status: 200,
                result
            })
        }else{
            res.send({
                status:500,
                msg:"暂无数据"
            })
        }
    })
})
// 社科主体账户
router.get("/bidding_subject",(req,res)=> {
    var search = req.query.search;
    const sql = "select * from bidding "+search;
    sqlFn(sql,null,(result)=>{
        if(result.length > 0){
            res.send({
                status: 200,
                result
            })
        }else{
            res.send({
                status:500,
                msg:"暂无数据"
            })
        }
    })
})

// 地区——省
router.get("/china_address_province",(req,res)=> {
    var search = req.query.search;
    const sql = "select * from china where pid='0' and id!= '0';";
    sqlFn(sql,null,(result)=>{
        if(result.length > 0){
            res.send({
                status: 200,
                result
            })
        }else{
            res.send({
                status:500,
                msg:"暂无数据"
            })
        }
    })
})
// 地区——市
router.get("/china_address_city",(req,res)=> {
    let search = req.query.pid;
    const sql = "select * from china where Pid = "+search;
    sqlFn(sql,null,(result)=>{
        if(result.length > 0){
            res.send({
                status: 200,
                result
            })
        }else{
            res.send({
                status:500,
                msg:"暂无数据"
            })
        }
    })
})
// 地区——县
router.get("/china_address_county",(req,res)=> {
    var search = req.query.pid;
    const sql = "select * from china where Pid = "+search;
    sqlFn(sql,null,(result)=>{
        if(result.length > 0){
            res.send({
                status: 200,
                result
            })
        }else{
            res.send({
                status:500,
                msg:"暂无数据"
            })
        }
    })
})





module.exports=router